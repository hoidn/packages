from distutils.core import setup

setup(name='mu',
      version='1.0',
      py_modules=['mu'],
      )
