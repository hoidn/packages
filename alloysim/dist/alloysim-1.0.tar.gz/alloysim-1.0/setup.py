from distutils.core import setup
setup(name = 'alloysim', 
    version = '1.0',
    py_modules = ['alloySim', 'optimizeAlloys'],
    )

